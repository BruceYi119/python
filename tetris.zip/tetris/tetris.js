const blockColors = ['red', 'green', 'skyblue', 'orange', 'pink', 'orange', 'yellow', 'purple'];
const blockData = [
	[[1, 1, 1, 1]],
	[[1, 1], [1, 1]],
	[[0, 1, 0], [1, 1, 1]],
	[[1, 1, 0], [0, 1, 1]],
	[[0, 1, 1], [1, 1, 0]],
	[[1, 0, 0], [1, 1, 1]],
	[[0, 0, 1], [1, 1, 1]]
];
const loc = {
	UP: 2,
	DOWN: 0,
	LEFT: -1,
	RIGHT: 1
};
let tetris;
let maxrow;
let maxcol;
let tetrisData = [];
let prevTetrisData = [];
let block;
let color;
let row = 0;
let col = 3;
let moveInterval = null;

const move = (l) => {
	l = l || 0;
	let b = block.length - 1;

	for (var i = maxcol; i >= 0; i--) {
		prevTetrisData[i].forEach(function(td, j) {
			if (td === 1 && row + b < maxrow) {
				switch (loc) {
					case loc.DOWN:
						tetrisData[i + 1][j] = td;
						tetrisData[i][j] = 0;
						break;
					case loc.RIGHT:
						let c = block[0].length;
						if (j >= col && j + c - 1 < 10) {
							tetrisData[i][j + 1] = td;
							if (col === j)
								tetrisData[i][j] = 0;
						}
						break;
					case loc.LEFT:
						tetrisData[i][j + 1] = td;
						tetrisData[i][j] = 0;
						break;
				};
			}
		});
	}

	setPrevData();

	if (loc === 0 && row + b < maxrow) row++;
	if (loc === 1 && col < maxcol) col++;

	tetrisRender();
	if (row + b === maxrow && moveInterval) {
		clearInterval(moveInterval);
		moveInterval = null;
		setBlock();
		row = 0;
		col = 3;
	}
	//    if (moveInterval === null) {
	//        moveInterval = setInterval(function(){ move(0); }, 100);
	//    }
};

const tetrisRender = () => {
	tetrisData.forEach(function(tr, i) {
		tr.forEach(function(td, j) {
			let cel = tetris.children[i].children[j];

			if (td === 1)
				cel.className = color;
			else
				cel.className = '';
		});
	});
};

const setTetris = () => {
	tetris = document.querySelector('#tetris');
	let fragment = document.createDocumentFragment();
	setBlock();

	for (var i = 0; i < 20; i++) {
		let tr = document.createElement('tr');
		let trArr = [];
		fragment.appendChild(tr);
		tetrisData.push(trArr);

		for (var j = 0; j < 10; j++) {
			let td = document.createElement('td');
			let tdArr = [];
			tr.appendChild(td);

			if (i < block.length && block[i][j - 3] && block[i][j - 3] === 1) {
				trArr.push(1);
			} else {
				trArr.push(0);
			}
		}
	}

	setPrevData();

	tetris.appendChild(fragment);
	maxrow = tetris.lastChild.rowIndex;
	maxcol = tetris.lastChild.lastChild.cellIndex;
};

const setPrevData = () => {
	prevTetrisData = [
		[].concat(...tetrisData[0]),
		[].concat(...tetrisData[1]),
		[].concat(...tetrisData[2]),
		[].concat(...tetrisData[3]),
		[].concat(...tetrisData[4]),
		[].concat(...tetrisData[5]),
		[].concat(...tetrisData[6]),
		[].concat(...tetrisData[7]),
		[].concat(...tetrisData[8]),
		[].concat(...tetrisData[9])
	];
};

const setBlock = () => {
	color = blockColors[Math.floor(Math.random() * 8)];
	block = blockData[Math.floor(Math.random() * 7)];
};

window.addEventListener('keyup', function(e) {
	switch (e.keyCode) {
		case 32:        // 스페이스
			console.log('스페이스');
			break;
		case 38:        // 위
			move(loc.UP);
			break;
		case 39:        // 오른쪽
			move(loc.RIGHT);
			break;
		case 40:        // 아래
			move(loc.DOWN);
			break;
		case 37:        // 왼쪽
			move(loc.LEFT);
			break;
		default:
			break;
	}
});

setTetris();
tetrisRender();
//moveInterval = setInterval(function() { move(); }, 100);